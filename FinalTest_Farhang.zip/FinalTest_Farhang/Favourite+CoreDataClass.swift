//
//  Favourite+CoreDataClass.swift
//  FinalTest_Farhang
//
//  Created by Farhang on 04/20/22.
//
//

import Foundation
import CoreData

@objc(Favourite)
public class Favourite: NSManagedObject {

}
