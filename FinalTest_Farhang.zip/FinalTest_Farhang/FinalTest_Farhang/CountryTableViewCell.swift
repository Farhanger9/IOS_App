//
//  CountryTableViewCell.swift
//  FinalTest_Farhang
//
//  Created by Farhang on 04/20/22.
//

import UIKit

class CountryTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func initialise(title:String){
        self.titleLbl.text = title
    }
    
}
