//
//  ListingViewController.swift
//  FinalTest_Farhang
//
//  Created by Farhang on 04/20/22.
//

import UIKit

class ListingViewController: UIViewController , UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var tableView: UITableView!
    
    var countryModels:[CountryModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Countries Listing"
        self.tableView.dataSource = self
        self.tableView.delegate = self
        fetchData()
        
    }

    func fetchData(){
     
//
//        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
//            guard let data = data else { return }
//
//        }
        
        let urlPath = "https://restcountries.com/v2/all"
            let url = URL(string: urlPath)!
            let session = URLSession.shared
            let task = session.dataTask(with: url) { data, response, error in
               

                guard let data = data, error == nil else {
                
                    return
                }

                do {
                    if let jsonResult = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
//                        if let results = jsonResult["results"] as? [Any] {
//                            DispatchQueue.main.async {
//                                self.tableData = results
//                                self.indexTableView.reloadData()
//                            }
//                        }
                        
                        self.parseData(json: jsonResult)
                    }
                } catch let parseError {
                    print("JSON Error \(parseError.localizedDescription)")
                }
            }

            task.resume()
        
    }
    
    func parseData(json:[[String:Any]]){
        var countryName:String =  ""
        var countryCapital:String = ""
        var countrycode:String = ""
        var countryPopulation:String = ""
        
        for item in json{
            
            if let name  = item["name"] as? String{
                countryName = name
            }
            if let capital = item["capital"] as? String{
                countryCapital = capital
            }
            
            if let code  = item["numericCode"] as? String{
                countrycode = code
            }
            if let population = item["population"] as? Double{
                countryPopulation = String(Int(population))
            }
            if countryName == "Canada"{
                UserDefaults.standard.set(countryPopulation, forKey: "canadaPopulation")
            }
            
            let model = CountryModel(countryName: countryName, capital: countryCapital, countryCode: countrycode, population: countryPopulation)
            self.countryModels.append(model)
            
        }
            DispatchQueue.main.async {
                self.tableView.reloadData()
                
            }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return countryModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CountryTableViewCell", for: indexPath) as! CountryTableViewCell
        let model = self.countryModels[indexPath.row]
        cell.initialise(title:model.countryName)
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = self.countryModels[indexPath.row]
        let story = UIStoryboard(name: "Main", bundle:nil)
        let vc = story.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        vc.countryModel = model
        self.navigationController?.pushViewController(vc, animated: true)
        
    }

 
}
