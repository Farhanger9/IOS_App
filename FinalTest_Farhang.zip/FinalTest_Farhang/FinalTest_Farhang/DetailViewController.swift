//
//  DetailViewController.swift
//  FinalTest_Farhang
//
//  Created by Farhang on 04/20/22.
//

import UIKit

class DetailViewController: UIViewController {
    let context  = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var codeLbl: UILabel!
    @IBOutlet weak var capitalLbl: UILabel!
    
    @IBOutlet weak var populationLbl: UILabel!
    
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var errorLbl: UILabel!
    var countryModel:CountryModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        if let model = self.countryModel{
            initialise(countryModel: model)
            self.errorLbl.isHidden = true
            self.errorLbl.text = "Sorry, no country information found"
        }else{
            displayError()
        }
    }
    
    func initialise(countryModel:CountryModel){
        self.nameLbl.text = countryModel.countryName
        self.codeLbl.text  = countryModel.countryCode
        self.capitalLbl.text = countryModel.capital
        self.populationLbl.text = countryModel.population
    }
     
    func displayError(){
        self.nameLbl.isHidden = true
        self.capitalLbl.isHidden = true
        self.codeLbl.isHidden = true
        self.populationLbl.isHidden = true
        self.addBtn.isHidden = true
        self.errorLbl.isHidden = false
    }
    
    @IBAction func addToFavouriteTapped(_ sender: Any) {
        let favourite = Favourite(context: self.context)
        favourite.name = countryModel?.countryName
        favourite.population = Int64(countryModel?.population ?? "0")!
        do{
        try self.context.save()
            let alert = UIAlertController(title: "Successfull", message: "Country has been saved", preferredStyle: UIAlertController.Style.alert)

                    // add an action (button)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))

                    // show the alert
                    self.present(alert, animated: true, completion: nil)
        }catch{
            print("error in coredata")
            
        }
    }
    
    
}
