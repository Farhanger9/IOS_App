//
//  CountryModel.swift
//  FinalTest_Farhang
//
//  Created by Farhang on 04/20/22.
//

import Foundation


struct CountryModel{
    var countryName:String
    var capital:String
    var countryCode:String
    var population:String
}
