//
//  FavouriteViewController.swift
//  FinalTest_Farhang
//
//  Created by Farhang on 04/20/22.
//

import UIKit

class FavouriteViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    
    var favourites:[Favourite] = []
    @IBOutlet weak var tableView: UITableView!
    let context  = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let canadaPopulation = UserDefaults.standard.string(forKey: "canadaPopulation")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.title = "Favourites"
        fetchData()
    
    }
    
    override func viewWillAppear(_ animated: Bool) {
        fetchData()
    }
    
    func fetchData(){
        do{
            self.favourites =  try context.fetch(Favourite.fetchRequest())
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }
        catch{
            print("Error in ")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favourites.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FavouriteTableViewCell", for: indexPath) as! FavouriteTableViewCell
        let model = self.favourites[indexPath.row]
        if Int(model.population) > Int(canadaPopulation!) ?? 0 {
            cell.backgroundColor = UIColor.systemPink
        }else{
            cell.backgroundColor = UIColor.systemBackground
        }
        cell.initialise(title: model.name ?? "", subtitle: String(model.population))
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if(editingStyle == .delete){
            let model = self.favourites[indexPath.row]
                self.favourites.remove(at: indexPath.row)
                self.tableView.reloadData()
                // DELETE FROM THE COREDATA
            context.delete(model)
            do{
            try context.save()
            }catch{
                
            }
           
        }
    }

}
