//
//  FavouriteTableViewCell.swift
//  FinalTest_Farhang
//
//  Created by Farhang on 04/20/22.
//

import UIKit

class FavouriteTableViewCell: UITableViewCell {

    @IBOutlet weak var subtitleLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func initialise(title:String,subtitle:String){
        self.titleLbl.text = title
        self.subtitleLbl.text = subtitle
    }

}
