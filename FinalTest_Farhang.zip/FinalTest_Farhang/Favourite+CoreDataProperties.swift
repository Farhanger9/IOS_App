//
//  Favourite+CoreDataProperties.swift
//  FinalTest_Farhang
//
//  Created by Farhang on 04/20/22.
//
//

import Foundation
import CoreData


extension Favourite {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Favourite> {
        return NSFetchRequest<Favourite>(entityName: "Favourite")
    }

    @NSManaged public var name: String?
    @NSManaged public var population: Int64

}

extension Favourite : Identifiable {

}
